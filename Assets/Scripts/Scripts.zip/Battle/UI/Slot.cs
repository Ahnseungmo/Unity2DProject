using UnityEngine;
using UnityEngine.UI;

public class Slot : MonoBehaviour
{
    RawImage rawImage;
    public GameObject gameObject;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rawImage = GetComponent<RawImage>();
        rawImage.texture = gameObject.GetComponent<SpriteRenderer>().sprite.texture;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
